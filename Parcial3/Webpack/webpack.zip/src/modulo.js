export function cuadrado(valorAConvertir){
    return valorAConvertir * valorAConvertir
}
