import {cuadrado} from "./modulo"
console.log("Hello world");
console.log(cuadrado(2));